import{a as t}from"../chunks/entry.D7mS5xcT.js";export{t as start};
