import{a as t}from"../chunks/entry.BNNndjIF.js";export{t as start};
